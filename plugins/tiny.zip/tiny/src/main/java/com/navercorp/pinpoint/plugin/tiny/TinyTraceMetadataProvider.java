package com.navercorp.pinpoint.plugin.tiny;

import com.navercorp.pinpoint.common.trace.TraceMetadataProvider;
import com.navercorp.pinpoint.common.trace.TraceMetadataSetupContext;

/**
 * @Author： Spin
 * @Date： 2021/11/3 2:19 下午
 * @Desc:
 */
public class TinyTraceMetadataProvider implements TraceMetadataProvider {
    static {
        System.out.println("TINY 链路检测插件 TinyTraceMetadataProvider");
    }
    @Override
    public void setup(TraceMetadataSetupContext context) {
        context.addServiceType(TinyConstants.TINY_SERVER_SERVICE_TYPE);
        context.addServiceType(TinyConstants.TINY_CLIENT_SERVICE_TYPE);
        context.addServiceType(TinyConstants.TINY_SERVER_SERVICE_NO_STATISTICS_TYPE);
        context.addAnnotationKey(TinyConstants.TINY_ARGS_ANNOTATION_KEY);
        context.addAnnotationKey(TinyConstants.TINY_RESULT_ANNOTATION_KEY);
        context.addAnnotationKey(TinyConstants.TINY_RPC_ANNOTATION_KEY);

    }
}
