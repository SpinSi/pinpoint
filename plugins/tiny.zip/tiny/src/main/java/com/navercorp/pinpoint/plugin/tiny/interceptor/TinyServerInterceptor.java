package com.navercorp.pinpoint.plugin.tiny.interceptor;

import com.alibaba.fastjson.JSON;
import com.navercorp.pinpoint.bootstrap.context.*;
import com.navercorp.pinpoint.bootstrap.interceptor.SpanRecursiveAroundInterceptor;
import com.navercorp.pinpoint.bootstrap.util.NumberUtils;
import com.navercorp.pinpoint.common.plugin.util.HostAndPort;
import com.navercorp.pinpoint.common.trace.ServiceType;
import com.navercorp.pinpoint.plugin.tiny.TinyConstants;
import com.navercorp.pinpoint.plugin.tiny.TinyServerMethodDescriptor;
import com.navercorp.pinpoint.plugin.tiny.TinyUtil;
import io.netty.channel.ChannelHandlerContext;
import org.tinygroup.context.Context;
import org.tinygroup.event.Event;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.Map;

/**
 * 拦截 org.tinygroup.cepcoremutiremoteimpl.node.server.NodeServerHandler.dealRemoteRequest(Event event,ChannelHandlerContext ctx)
 *
 * @Author： Spin
 * @Date： 2021/11/2 1:58 下午
 * @Desc: extends SpanRecursiveAroundInterceptor
 */
public class TinyServerInterceptor extends SpanRecursiveAroundInterceptor {
    static {
        System.out.println("TINY 链路检测插件 TinyServerInterceptor");
    }
    private static final String SCOPE_NAME = "##TINY_SERVER_TRACE";
    private static final MethodDescriptor TINY_SERVER_METHOD_DESCRIPTOR = new TinyServerMethodDescriptor();

    protected TinyServerInterceptor(TraceContext traceContext, MethodDescriptor methodDescriptor, String scopeName) {
        super(traceContext, methodDescriptor, SCOPE_NAME);
        traceContext.cacheApi(TINY_SERVER_METHOD_DESCRIPTOR);
    }

    /**
     * 拦截 org.tinygroup.cepcoremutiremoteimpl.node.server.NodeServerHandler.dealRemoteRequest(Event event,ChannelHandlerContext ctx)
     *
     * @param recorder
     * @param target
     * @param args
     */
    @Override
    protected void doInBeforeTrace(SpanEventRecorder recorder, Object target, Object[] args) {
        final Event tinyEvent = (Event) args[0];
        logger.info("tiny rpc  TinyServerInterceptor.doInBeforeTrace tinyEvent={}", JSON.toJSONString(tinyEvent));
        recorder.recordServiceType(TinyConstants.TINY_SERVER_SERVICE_NO_STATISTICS_TYPE);
        recorder.recordApi(methodDescriptor);
        String serviceId = tinyEvent.getServiceRequest().getServiceId();

        recorder.recordAttribute(TinyConstants.TINY_RPC_ANNOTATION_KEY,
                TinyUtil.getInterfaceName(serviceId) + ":" + TinyUtil.getMethodName(serviceId));

    }

    @Override
    protected Trace createTrace(Object target, Object[] args) {
        final Trace trace = readRequestTrace(target, args);
        logger.info("tiny rpc  TinyServerInterceptor.createTrace trace={}", JSON.toJSONString(trace));

        if (trace.canSampled()) {
            final SpanRecorder recorder = trace.getSpanRecorder();
            // You have to record a service type within Server range.
            recorder.recordServiceType(TinyConstants.TINY_SERVER_SERVICE_TYPE);
            recorder.recordApi(TINY_SERVER_METHOD_DESCRIPTOR);
            recordRequest(recorder, target, args);
        }

        return trace;
    }

    @Override
    protected void doInAfterTrace(SpanEventRecorder recorder, Object target, Object[] args, Object result, Throwable throwable) {
        final Event tinyEvent = (Event) args[0];
        logger.info("tiny rpc  TinyServerInterceptor.doInAfterTrace tinyEvent={}", JSON.toJSONString(tinyEvent));

        recorder.recordApi(methodDescriptor);
        recorder.recordAttribute(TinyConstants.TINY_ARGS_ANNOTATION_KEY, tinyEvent.getServiceRequest());

        if (throwable == null) {
            recorder.recordAttribute(TinyConstants.TINY_RESULT_ANNOTATION_KEY, result);
        } else {
            recorder.recordException(throwable);
        }
    }


    private Trace readRequestTrace(Object target, Object[] args) {
        final Event event = (Event) args[0];
        // Ignore monitor service.
        if (TinyConstants.MONITOR_SERVICE_ID.equals(event.getServiceRequest().getServiceId())) {
            return traceContext.disableSampling();
        }
        Context tinyContext = event.getServiceRequest().getContext();
        // If this transaction is not traceable, mark as disabled.
        if (tinyContext.get(TinyConstants.META_DO_NOT_TRACE) != null) {
            return traceContext.disableSampling();
        }
        final String transactionId = tinyContext.get(TinyConstants.META_TRANSACTION_ID);
        // If there's no trasanction id, a new trasaction begins here.
        // We'll have to check if a trace object already exists and create a span event instead of a span in that case.
        if (transactionId == null) {
            return traceContext.newTraceObject();
        }
        // otherwise, continue tracing with given data.
        final long parentSpanID = NumberUtils.parseLong(tinyContext.<String>get(TinyConstants.META_PARENT_SPAN_ID), SpanId.NULL);
        final long spanID = NumberUtils.parseLong(tinyContext.<String>get(TinyConstants.META_SPAN_ID), SpanId.NULL);
        final short flags = NumberUtils.parseShort(tinyContext.<String>get(TinyConstants.META_FLAGS), (short) 0);
        final TraceId traceId = traceContext.createTraceId(transactionId, parentSpanID, spanID, flags);
        return traceContext.continueTraceObject(traceId);
    }


    private void recordRequest(SpanRecorder recorder, Object target, Object[] args) {
        final Event tinyEvent = (Event) args[0];

        // Record rpc name, client address, server address.
//        recorder.recordRpcName(invoker.getInterface().getSimpleName() + ":" + tinyEvent.getMethodName());
        // serviceId like com.hyxf.credit.tiny.facade.CreditServiceFacade.queryAdjustDetailList

        String serviceId = tinyEvent.getServiceRequest().getServiceId();
        String interfaceName = TinyUtil.getInterfaceName(serviceId);
        String methodName = TinyUtil.getMethodName(serviceId);
        recorder.recordRpcName(interfaceName + ":" + methodName);

        Context tinyContext = tinyEvent.getServiceRequest().getContext();
        ChannelHandlerContext handlerContext = (ChannelHandlerContext) args[1];
        recorder.recordEndPoint(getEndPoint(handlerContext));
        String remoteHost = (String) tinyContext.get(TinyConstants.META_HOST);
        if (remoteHost != null) {
            recorder.recordRemoteAddress(remoteHost);
        } else {
            recorder.recordRemoteAddress("Unknown");
        }
        // If this transaction did not begin here, record parent(client who sent this request) information
        if (!recorder.isRoot()) {
            final String parentApplicationName = tinyContext.get(TinyConstants.META_PARENT_APPLICATION_NAME);
            if (parentApplicationName != null) {
                final short parentApplicationType = NumberUtils.parseShort(tinyContext.<String>get(TinyConstants.META_PARENT_APPLICATION_TYPE), ServiceType.UNDEFINED.getCode());
                recorder.recordParentApplication(parentApplicationName, parentApplicationType);
                final String host = tinyContext.get(TinyConstants.META_HOST);
                if (host != null) {
                    recorder.recordAcceptorHost(host);
                } else {
                    // old version fallback
                    final String estimatedLocalHost = getLocalHost(tinyContext);
                    if (estimatedLocalHost != null) {
                        recorder.recordAcceptorHost(estimatedLocalHost);
                    }
                }
            }
        }
        //clear attachments,链路中的trace信息已经写入threadLocal
        this.clearMetaItem(tinyContext);
    }

    private String getEndPoint(ChannelHandlerContext handlerContext) {

        SocketAddress socketAddress = handlerContext.channel().localAddress();
        if (socketAddress instanceof InetSocketAddress) {
            final InetSocketAddress inetSocketAddress = (InetSocketAddress) socketAddress;
            final InetAddress remoteAddress = inetSocketAddress.getAddress();
            if (remoteAddress != null) {
                return HostAndPort.toHostAndPortString(remoteAddress.getHostAddress(),
                        inetSocketAddress.getPort());
            }
            // Warning : InetSocketAddressAvoid unnecessary DNS lookup  (warning:InetSocketAddress.getHostName())
            final String hostName = inetSocketAddress.getHostName();
            if (hostName != null) {
                return HostAndPort.toHostAndPortString(hostName, inetSocketAddress.getPort());
            }
        }
        return null;
    }


    private String getLocalHost(Context tinyContext) {
        // @Nullable
        final String localHost = TinyUtil.getLocalHost();
        if (localHost == null) {
            logger.debug("TinyUtil.getLocalHost() is null");
        }
        final String metaRemoteIp = tinyContext.get(TinyConstants.META_REMOTE_IP);
        final String metaRemotePort = tinyContext.get(TinyConstants.META_REMOTE_PORT);

        if (metaRemoteIp == null) {
            logger.debug("META_REMOTE_IP  is null");
        }
        if (localHost == null && metaRemoteIp == null) {
            logger.debug("localHost == null && META_REMOTE_IP == null");
            return null;
        }
        if (localHost == null) {
            logger.debug("return META_REMOTE_IP :{}", metaRemoteIp + ":" + metaRemotePort);
            return metaRemoteIp + ":" + metaRemotePort;
        }
        return localHost + ":" + metaRemotePort;
    }


    private void clearMetaItem(Context tinyContext) {
        Map<String, Object> attachments = tinyContext.getItemMap();
        if (attachments != null) {
            attachments.remove(TinyConstants.META_TRANSACTION_ID);
            attachments.remove(TinyConstants.META_SPAN_ID);
            attachments.remove(TinyConstants.META_PARENT_SPAN_ID);
            attachments.remove(TinyConstants.META_PARENT_APPLICATION_TYPE);
            attachments.remove(TinyConstants.META_PARENT_APPLICATION_NAME);
            attachments.remove(TinyConstants.META_FLAGS);
            attachments.remove(TinyConstants.META_HOST);
            attachments.remove(TinyConstants.META_REMOTE_IP);
            attachments.remove(TinyConstants.META_REMOTE_PORT);
        }
    }


//    protected Trace createTrace(Object target, Object[] args) {
//        final Trace trace = readRequestTrace(target, args);
//        if (trace.canSampled()) {
//            final SpanRecorder recorder = trace.getSpanRecorder();
//            // You have to record a service type within Server range.
//            recorder.recordServiceType(DubboConstants.DUBBO_PROVIDER_SERVICE_TYPE);
//            recorder.recordApi(DUBBO_PROVIDER_METHOD_DESCRIPTOR);
//            recordRequest(recorder, target, args);
//        }
//
//        return trace;
//    }
//


    //
//    /**
//     * clear {@link com.alibaba.dubbo.rpc.RpcContext#getAttachments()} trace header.
//     * you should to know,since dubbo 2.6.2 version.
//     * {@link com.alibaba.dubbo.rpc.protocol.AbstractInvoker#invoke(com.alibaba.dubbo.rpc.Invocation)}
//     * will force put {@link com.alibaba.dubbo.rpc.RpcContext#getAttachments()} to current Invocation
//     * replace origin invocation.addAttachmentsIfAbsent(context) method;
//     * to imagine if application(B) methodB called by application(A), application(B) is dubbo provider, methodB call next dubbo application(C).
//     * when application(C) received trace header is overwrite by application(B) received trace header.
//     *
//     * @param rpcContext
//     */
//    private void clearAttachments(RpcContext rpcContext) {
//        Map<String, String> attachments = rpcContext.getAttachments();
//        if (attachments != null) {
//            attachments.remove(DubboConstants.META_TRANSACTION_ID);
//            attachments.remove(DubboConstants.META_SPAN_ID);
//            attachments.remove(DubboConstants.META_PARENT_SPAN_ID);
//            attachments.remove(DubboConstants.META_PARENT_APPLICATION_TYPE);
//            attachments.remove(DubboConstants.META_PARENT_APPLICATION_NAME);
//            attachments.remove(DubboConstants.META_FLAGS);
//            attachments.remove(DubboConstants.META_HOST);
//        }
//    }
//
//    private String getLocalHost(RpcContext rpcContext) {
//        // Pinpoint finds caller - callee relation by matching caller's end point and callee's acceptor host.
//        // https://github.com/naver/pinpoint/issues/1395
//        return rpcContext.getLocalAddressString();
//
//    }
//


//    @Override
//    protected void doInBeforeTrace(SpanEventRecorder recorder, Object target, Object[] args) {
//        final RpcInvocation invocation = (RpcInvocation) args[0];
//        recorder.recordServiceType(DubboConstants.DUBBO_PROVIDER_SERVICE_NO_STATISTICS_TYPE);
//        recorder.recordApi(methodDescriptor);
//        final Invoker invoker = (Invoker) target;
//
//        recorder.recordAttribute(DubboConstants.DUBBO_RPC_ANNOTATION_KEY,
//                invoker.getInterface().getSimpleName() + ":" + invocation.getMethodName());
//    }
//
//    @Override
//    protected void doInAfterTrace(SpanEventRecorder recorder, Object target, Object[] args, Object result, Throwable throwable) {
//        final RpcInvocation invocation = (RpcInvocation) args[0];
//        recorder.recordApi(methodDescriptor);
//        recorder.recordAttribute(DubboConstants.DUBBO_ARGS_ANNOTATION_KEY, invocation.getArguments());
//
//        if (throwable == null) {
//            recorder.recordAttribute(DubboConstants.DUBBO_RESULT_ANNOTATION_KEY, result);
//        } else {
//            recorder.recordException(throwable);
//        }
//    }
}
