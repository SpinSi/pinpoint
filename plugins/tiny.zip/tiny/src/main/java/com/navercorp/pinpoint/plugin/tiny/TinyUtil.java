package com.navercorp.pinpoint.plugin.tiny;

import com.navercorp.pinpoint.bootstrap.logging.PLogger;
import com.navercorp.pinpoint.bootstrap.logging.PLoggerFactory;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

/**
 * @Author： Spin
 * @Date： 2021/11/3 10:49 上午
 * @Desc:
 */
public class TinyUtil {

    private static final PLogger logger = PLoggerFactory.getLogger(TinyUtil.class);

    private static volatile String LOCAL_ADDRESS_CACHE;

    /**
     * serviceId like com.hyxf.credit.tiny.facade.CreditServiceFacade.queryAdjustDetailList
     */
    public static String getInterfaceName(String serviceId) {
        String[] elss = serviceId.split("\\.");
        return elss[elss.length - 2];
    }

    public static String getFullInterfaceName(String serviceId) {
        Integer lastIdx = serviceId.lastIndexOf(".");
        return serviceId.substring(0,lastIdx);
    }

    public static String getMethodName(String serviceId) {
        String[] elss = serviceId.split("\\.");
        return elss[elss.length - 1];
    }


    public static String getLocalHost() {
        if (LOCAL_ADDRESS_CACHE != null) {
            // expire time?
            return LOCAL_ADDRESS_CACHE;
        }
        String localHost = getLocalHost0();
        LOCAL_ADDRESS_CACHE = localHost;
        return localHost;
    }

    private static String getLocalHost0() {
        try {
            Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
            while (allNetInterfaces.hasMoreElements()) {
                NetworkInterface netInterface = allNetInterfaces.nextElement();
                String name = netInterface.getName();
                if (!name.contains("docker") && !name.contains("lo")) {
                    Enumeration<InetAddress> addresses = netInterface.getInetAddresses();
                    while (addresses.hasMoreElements()) {
                        InetAddress ip = addresses.nextElement();
                        if (ip != null && ip instanceof Inet4Address && !ip.isLoopbackAddress()) {
                            final String hostAddress = ip.getHostAddress();
                            if (hostAddress.indexOf(':') == -1) {
                                // TODO We do not seem to understand this problem exactly.
                                logger.info("Tiny rpc localAddress cache:{}", hostAddress);
                                return hostAddress;
                            }
                        }
                    }
                }
            }
        } catch (SocketException e) {
            logger.error("failed to get local host", e);
            return null;
        }
        return null;
    }
}
