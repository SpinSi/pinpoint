package com.navercorp.pinpoint.plugin.tiny;

import com.navercorp.pinpoint.common.trace.AnnotationKey;
import com.navercorp.pinpoint.common.trace.AnnotationKeyFactory;
import com.navercorp.pinpoint.common.trace.ServiceType;
import com.navercorp.pinpoint.common.trace.ServiceTypeFactory;
import org.tinygroup.cepcoremutiremoteimpl.node.client.NodeClientHandler;

import static com.navercorp.pinpoint.common.trace.AnnotationKeyProperty.VIEW_IN_RECORD_SET;
import static com.navercorp.pinpoint.common.trace.ServiceTypeProperty.RECORD_STATISTICS;

/**
 * @Author： Spin
 * @Date： 2021/11/2 1:56 下午
 * @Desc:
 */
public class TinyConstants {

    protected TinyConstants() {

    }

    public static final ServiceType TINY_CLIENT_SERVICE_TYPE = ServiceTypeFactory.of(951, "TINY_CLIENT", RECORD_STATISTICS);
    public static final ServiceType TINY_SERVER_SERVICE_TYPE = ServiceTypeFactory.of(952, "TINY_SERVER", RECORD_STATISTICS);
    public static final ServiceType TINY_SERVER_SERVICE_NO_STATISTICS_TYPE = ServiceTypeFactory.of(953, "TINY");


    public static final AnnotationKey TINY_ARGS_ANNOTATION_KEY = AnnotationKeyFactory.of(961, "tiny.args");
    public static final AnnotationKey TINY_RESULT_ANNOTATION_KEY = AnnotationKeyFactory.of(962, "tiny.result");
    public static final AnnotationKey TINY_RPC_ANNOTATION_KEY = AnnotationKeyFactory.of(963, "tiny.rpc", VIEW_IN_RECORD_SET);

    public static final String META_DO_NOT_TRACE = "PIN_PON_TINY_DO_NOT_TRACE";
    public static final String META_TRANSACTION_ID = "PIN_PON_TINY_TRASACTION_ID";
    public static final String META_SPAN_ID = "PIN_PON_TINY_SPAN_ID";
    public static final String META_PARENT_SPAN_ID = "PIN_PON_TINY_PARENT_SPAN_ID";
    public static final String META_PARENT_APPLICATION_NAME = "PIN_PON_TINY_PARENT_APPLICATION_NAME";
    public static final String META_PARENT_APPLICATION_TYPE = "PIN_PON_TINY_PARENT_APPLICATION_TYPE";
    public static final String META_FLAGS = "PIN_PON_TINY_FLAGS";
    public static final String META_HOST = "PIN_PON_TINY_HOST";

    public static final String META_REMOTE_IP = "PIN_PON_TINY_HOST_IP";
    public static final String META_REMOTE_PORT = "PIN_PON_TINY_HOST_PORT";

    public static final String MONITOR_SERVICE_ID = NodeClientHandler.HEART_BEAT_KEY_NODE_CLIENT;
}
