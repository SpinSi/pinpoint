package com.navercorp.pinpoint.plugin.tiny;

import com.navercorp.pinpoint.bootstrap.context.MethodDescriptor;
import com.navercorp.pinpoint.common.trace.MethodType;
import com.navercorp.pinpoint.common.util.LineNumber;

/**
 * @Author： Spin
 * @Date： 2021/11/3 9:42 上午
 * @Desc:
 */
public class TinyServerMethodDescriptor implements MethodDescriptor {
    private int apiId = 0;

    @Override
    public String getMethodName() {

        return null;
    }

    @Override
    public String getClassName() {
        return null;
    }

    @Override
    public String[] getParameterTypes() {
        return new String[0];
    }

    @Override
    public String[] getParameterVariableName() {
        return new String[0];
    }

    @Override
    public String getParameterDescriptor() {
        return null;
    }

    @Override
    public int getLineNumber() {
        return LineNumber.NO_LINE_NUMBER;
    }

    @Override
    public String getFullName() {
        return "com.navercorp.pinpoint.plugin.tiny.TinyServerMethodDescriptor.invoke()";
    }

    @Override
    public void setApiId(int apiId) {
        this.apiId = apiId;
    }

    @Override
    public int getApiId() {
        return apiId;
    }

    @Override
    public String getApiDescriptor() {
        return "Tiny Server Process";

    }

    @Override
    public int getType() {
        return MethodType.WEB_REQUEST;
    }
}
