package com.navercorp.pinpoint.plugin.tiny;

import com.navercorp.pinpoint.bootstrap.instrument.InstrumentClass;
import com.navercorp.pinpoint.bootstrap.instrument.InstrumentException;
import com.navercorp.pinpoint.bootstrap.instrument.InstrumentMethod;
import com.navercorp.pinpoint.bootstrap.instrument.Instrumentor;
import com.navercorp.pinpoint.bootstrap.instrument.transformer.TransformCallback;
import com.navercorp.pinpoint.bootstrap.instrument.transformer.TransformTemplate;
import com.navercorp.pinpoint.bootstrap.instrument.transformer.TransformTemplateAware;
import com.navercorp.pinpoint.bootstrap.logging.PLogger;
import com.navercorp.pinpoint.bootstrap.logging.PLoggerFactory;
import com.navercorp.pinpoint.bootstrap.plugin.ProfilerPlugin;
import com.navercorp.pinpoint.bootstrap.plugin.ProfilerPluginSetupContext;
import com.navercorp.pinpoint.plugin.tiny.interceptor.TinyClientInterceptor;
import com.navercorp.pinpoint.plugin.tiny.interceptor.TinyServerInterceptor;
import org.tinygroup.cepcoremutiremoteimpl.util.RemoteCepCoreUtil;

import java.security.ProtectionDomain;

/**
 * @Author： Spin
 * @Date： 2021/11/2 1:55 下午
 * @Desc:
 */
public class TinyProfilerPlugin implements ProfilerPlugin, TransformTemplateAware {
    static {
        System.out.println("TINY 链路检测插件 TinyProfilerPlugin");
    }
    private final PLogger logger = PLoggerFactory.getLogger(this.getClass());

    private TransformTemplate transformTemplate;

    @Override
    public void setup(ProfilerPluginSetupContext context) {


        if (!context.registerApplicationType(TinyConstants.TINY_SERVER_SERVICE_TYPE)) {
            logger.info("Tiny rpc Application type [{}] already set, skipping [{}] registration.", context.getApplicationType(),
                    TinyConstants.TINY_SERVER_SERVICE_TYPE);
        }

        this.addTransformers();
    }

    private void addTransformers() {
        transformTemplate.transform("org.tinygroup.cepcoremutiremoteimpl.util.RemoteCepCoreUtil", RemoteCepCoreUtilTransform.class);
        transformTemplate.transform("org.tinygroup.cepcoremutiremoteimpl.node.server.NodeServerHandler", NodeServerHandlerTransform.class);
    }

    //  * 拦截 org.tinygroup.cepcoremutiremoteimpl.util.RemoteCepCoreUtil.sendEvent(NodeClientImpl client, Event event)
    public static class RemoteCepCoreUtilTransform implements TransformCallback {
        @Override
        public byte[] doInTransform(Instrumentor instrumentor, ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws InstrumentException {
            final InstrumentClass target = instrumentor.getInstrumentClass(loader, className, classfileBuffer);
            InstrumentMethod invokeMethod = target.getDeclaredMethod("sendEvent",
                    "org.tinygroup.cepcoremutiremoteimpl.node.client.NodeClientImpl", "org.tinygroup.event.Event");
            if (invokeMethod != null) {
                invokeMethod.addInterceptor(TinyClientInterceptor.class);
            }
            return target.toBytecode();
        }
    }
// 拦截 org.tinygroup.cepcoremutiremoteimpl.node.server.NodeServerHandler.dealRemoteRequest(Event event,ChannelHandlerContext ctx)
    public static class NodeServerHandlerTransform implements TransformCallback {
        @Override
        public byte[] doInTransform(Instrumentor instrumentor, ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws InstrumentException {
            final InstrumentClass target = instrumentor.getInstrumentClass(loader, className, classfileBuffer);
            InstrumentMethod invokeMethod = target.getDeclaredMethod("dealRemoteRequest",
                    "org.tinygroup.event.Event", "io.netty.channel.ChannelHandlerContext");
            if (invokeMethod != null) {
                invokeMethod.addInterceptor(TinyServerInterceptor.class);
            }
            return target.toBytecode();
        }
    }


    @Override
    public void setTransformTemplate(TransformTemplate transformTemplate) {
        this.transformTemplate = transformTemplate;
    }


}
