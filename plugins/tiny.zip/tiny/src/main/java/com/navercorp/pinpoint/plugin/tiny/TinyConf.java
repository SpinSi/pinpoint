package com.navercorp.pinpoint.plugin.tiny;

import com.google.common.collect.Lists;
import com.navercorp.pinpoint.bootstrap.config.ProfilerConfig;

import java.util.List;

/**
 * @Author： Spin
 * @Date： 2021/11/2 1:55 下午
 * @Desc:
 */
public class TinyConf {

    private final boolean tinyEnabled;
    private final List<String> tinyBootstrapMains;

    public TinyConf(ProfilerConfig config) {
        this.tinyEnabled = config.readBoolean("profiler.tiny.enable", true);
        this.tinyBootstrapMains = Lists.newArrayList("org.tinygroup.tinyrunner.Runner");
//                config.readList("profiler.tiny.bootstrap.main");
    }

    public boolean isTinyEnabled() {
        return tinyEnabled;
    }

    public List<String> getTinyBootstrapMains() {
        return tinyBootstrapMains;
    }

    @Override
    public String toString() {
        return "TinyConf{" +
                "tinyEnabled=" + tinyEnabled +
                ", tinyBootstrapMains=" + tinyBootstrapMains +
                '}';
    }
}
