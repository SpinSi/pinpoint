package com.navercorp.pinpoint.plugin.tiny;

import org.junit.Assert;
import org.junit.Test;

/**
 * @Author： Spin
 * @Date： 2021/11/3 2:25 下午
 * @Desc:
 */
//@RunWith(MockitoJUnitRunner.class)
public class TinyUtilTest {

    @Test
    public void test() {
        String serviceId = "com.hyxf.credit.tiny.facade.CreditServiceFacade.queryAdjustDetailList";
        Assert.assertEquals("queryAdjustDetailList", TinyUtil.getMethodName(serviceId));
        Assert.assertEquals("com.hyxf.credit.tiny.facade.CreditServiceFacade", TinyUtil.getFullInterfaceName(serviceId));
        Assert.assertEquals("CreditServiceFacade", TinyUtil.getInterfaceName(serviceId));


    }

}
